import React, { useEffect, useState } from 'react'
import ItemDetail from '../ItemDetail/ItemDetail';
import { Collapse, Container, Row } from 'react-bootstrap'
import { productos } from "../../db/dbProducts.json";
import {
  useParams, Link
} from "react-router-dom";


function ItemDetailContainer() {

    let { id } = useParams();
    const [detail, setDetail] = useState([]);    

    useEffect(() => {
      new Promise((resolve, reject) => {  
       
      //const datos = props.productos;
      const datos = productos.filter( (prod) =>  prod.id === id);
      //console.log(datos);
  
        setTimeout(() => {          
          resolve({id:1, title:'Polera Niño', description:'Polera verano con logo', price: 6800 , pictureUrl : 'polera_nino.png'});        
        }, 2000);      
      }).then(resultado=>{
        setDetail(resultado)})       
    }, [])

    return (
        <div className="item-detail-container">                  
           <h1>Detalle del Producto</h1>
           <Container >
             <Row>
              <ItemDetail detail={detail} /> 
             </Row>
           </Container>       
        </div>           
    );
}

export default ItemDetailContainer
