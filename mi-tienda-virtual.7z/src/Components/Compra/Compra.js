import React from 'react'

function Compra() {
    return (
        <div>
            Estamos en carrito de compras!
        </div>
    )
}

export default Compra
