export const urlApiProducts = "http://localhost:3000/productos";
export const BASE_PATH = "http://localhost:3000";